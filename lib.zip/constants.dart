import 'package:flutter/material.dart';

const kblack = Color(0XFF1E2126);
const kyellow = Color(0XFFFDD92F);
const kfontblack = Color(0XFF636569);
const kred = Color(0XFFCE0803);
