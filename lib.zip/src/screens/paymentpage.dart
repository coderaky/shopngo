import 'package:flutter/material.dart';
import 'package:shopngo/constants.dart';

class payemtpage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: kyellow,
      body: Column(
        children: [
          Container(
            height: 200,
            color: Colors.green,
            child: Column(
              children: [
                SizedBox(width: double.infinity),
                SizedBox(height: 15),
                Text(
                  'Payment',
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: kyellow,
                      fontSize: 30),
                ),
                Text(
                  'Total Price',
                  style: TextStyle(
                      fontWeight: FontWeight.w200,
                      color: kyellow,
                      fontSize: 20),
                ),
                Text(
                  'Rs 442',
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color: kyellow,
                      fontSize: 40),
                ),
              ],
            ),
          )
        ],
      ),
    ));
  }
}
